{
    "name": "SaaS Quota Client",
    "summary": "Enforce record quotas from host API",
    "version": "1.0",
    "category": "SaaS",
    "author": "Your Company",
    "depends": ["sale", "account"],
    "data": [],
    "installable": True,
} 